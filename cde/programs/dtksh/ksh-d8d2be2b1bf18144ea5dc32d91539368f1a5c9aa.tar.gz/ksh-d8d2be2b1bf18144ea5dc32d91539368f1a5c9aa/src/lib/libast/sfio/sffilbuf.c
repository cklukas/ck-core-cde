/***********************************************************************
*                                                                      *
*               This software is part of the ast package               *
*          Copyright (c) 1985-2011 AT&T Intellectual Property          *
*          Copyright (c) 2020-2026 Contributors to ksh 93u+m           *
*                      and is licensed under the                       *
*                 Eclipse Public License, Version 2.0                  *
*                                                                      *
*                A copy of the License is available at                 *
*      https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html      *
*         (with md5 checksum 84283fa8859daf213bdda5a9f8d1be1d)         *
*                                                                      *
*                 Glenn Fowler <gsf@research.att.com>                  *
*                  David Korn <dgk@research.att.com>                   *
*                   Phong Vo <kpv@research.att.com>                    *
*                  Martijn Dekker <martijn@inlv.org>                   *
*            Johnothan King <johnothanking@protonmail.com>             *
*                                                                      *
***********************************************************************/
#include	"sfhdr.h"

/*	Fill the buffer of a stream with data.
**	If n < 0, sffilbuf() attempts to fill the buffer if it's empty.
**	If n == 0, if the buffer is not empty, just return the first byte;
**		otherwise fill the buffer and return the first byte.
**	If n > 0, even if the buffer is not empty, try a read to get as
**		close to n as possible. n is reset to -1 if stack pops.
**
**	Written by Kiem-Phong Vo
*/

ptrdiff_t _sffilbuf(Sfio_t*	f,	/* fill the read buffer of this stream */
		    ptrdiff_t	n)	/* see above */
{
	ptrdiff_t	r, ret;
	int		first, local, rc, justseek;
	unsigned int	rcrv;

	if(!f)
		return -1;

	GETLOCAL(f,local);

	/* any peek data must be preserved across stacked streams */
	rcrv = f->mode&(SFIO_RC|SFIO_RV|SFIO_LOCK);
	rc = f->getr;

	justseek = f->bits&SFIO_JUSTSEEK; f->bits &= ~SFIO_JUSTSEEK;

	for(first = 1;; first = 0, (f->mode &= (uint32_t)~SFIO_LOCK) )
	{	/* check mode */
		if(SFMODE(f,local) != SFIO_READ && _sfmode(f,SFIO_READ,local) < 0)
			return -1;
		SFLOCK(f,local);

		/* current extent of available data */
		if((r = f->endb-f->next) > 0)
		{	/* on first iteration, n is amount beyond current buffer;
			   afterward, n is the exact amount requested */
			if((first && n <= 0) || (!first && n <= r) ||
			   (f->flags&SFIO_STRING))
				break;

			/* try shifting left to make room for new data */
			if(!(f->bits&SFIO_MMAP) && f->next > f->data &&
			   n > (f->size - (f->endb-f->data)) )
			{	size_t	s = (size_t)r;

				/* try to maintain block alignment */
				if(f->blksz > 0 && ((unsigned)f->here%f->blksz) == 0 )
				{	s = (((size_t)r + f->blksz-1)/f->blksz)*f->blksz;
					if((ptrdiff_t)s+n > f->size)
						s = (size_t)r;
				}

				memmove(f->data, f->endb-s, s);
				f->next = f->data + (s-(size_t)r);
				f->endb = f->data + s;
			}
		}
		else if(!(f->flags&SFIO_STRING) && !(f->bits&SFIO_MMAP) )
			f->next = f->endb = f->endr = f->data;

		if(f->bits&SFIO_MMAP)
			r = n > 0 ? n : f->size;
		else if(!(f->flags&SFIO_STRING) )
		{	r = f->size - (f->endb - f->data); /* available buffer */
			if(n > 0)
			{	if(r > n && f->extent < 0 && (f->flags&SFIO_SHARE) )
					r = n;	/* read only as much as requested */
				else if(justseek && n <= (ssize_t)f->iosz && (ssize_t)f->iosz <= f->size)
					r = (ptrdiff_t)f->iosz;	/* limit buffer filling */
			}
		}

		/* SFRD takes care of discipline read and stack popping */
		f->mode |= rcrv;
		f->getr = rc;
		if((r = SFRD(f,f->endb,(size_t)r,f->disc)) >= 0)
		{	r = f->endb - f->next;
			break;
		}
	}

	SFOPEN(f,local);

	ret = (n == 0) ? (r > 0 ? *f->next++ : EOF) : r;

	return ret;
}
