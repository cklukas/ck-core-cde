/***********************************************************************
*                                                                      *
*               This software is part of the ast package               *
*          Copyright (c) 1985-2011 AT&T Intellectual Property          *
*          Copyright (c) 2020-2026 Contributors to ksh 93u+m           *
*                      and is licensed under the                       *
*                 Eclipse Public License, Version 2.0                  *
*                                                                      *
*                A copy of the License is available at                 *
*      https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html      *
*         (with md5 checksum 84283fa8859daf213bdda5a9f8d1be1d)         *
*                                                                      *
*                 Glenn Fowler <gsf@research.att.com>                  *
*                  David Korn <dgk@research.att.com>                   *
*                   Phong Vo <kpv@research.att.com>                    *
*                  Martijn Dekker <martijn@inlv.org>                   *
*            Johnothan King <johnothanking@protonmail.com>             *
*                                                                      *
***********************************************************************/

/*
 * -last fcntl
 */

#include <ast.h>

#ifdef fcntl

#include <ls.h>
#include <ast_tty.h>
#include <error.h>

#if F_SETFD >= _ast_F_LOCAL
#if _sys_filio
#include <sys/filio.h>
#endif
#endif

#undef	fcntl
extern int	fcntl(int, int, ...);

int
_ast_fcntl(int fd, int op, ...)
{
	int		n;
	int		save_errno;
	struct stat	st;
	va_list		ap;

	save_errno = errno;
	va_start(ap, op);
	if (op >= _ast_F_LOCAL) switch (op)
	{
#if F_DUPFD >= _ast_F_LOCAL
	case F_DUPFD:
		n = va_arg(ap, int);
		op = dup2(fd, n);
		break;
#endif
#if F_GETFL >= _ast_F_LOCAL
	case F_GETFL:
		op = fstat(fd, &st);
		break;
#endif
#if F_SETFD >= _ast_F_LOCAL && defined(FIOCLEX)
	case F_SETFD:
		n = va_arg(ap, int);
		op = ioctl(fd, n == FD_CLOEXEC ? FIOCLEX : FIONCLEX, 0);
		break;
#endif
	default:
		errno = EINVAL;
		op = -1;
		break;
	}
	else
	op = fcntl(fd, op, va_arg(ap, int));
	va_end(ap);
	return op;
}

#else

NoN(fcntl)

#endif /* fcntl */
