/***********************************************************************
*                                                                      *
*               This software is part of the ast package               *
*          Copyright (c) 1985-2012 AT&T Intellectual Property          *
*          Copyright (c) 2020-2026 Contributors to ksh 93u+m           *
*                      and is licensed under the                       *
*                 Eclipse Public License, Version 2.0                  *
*                                                                      *
*                A copy of the License is available at                 *
*      https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html      *
*         (with md5 checksum 84283fa8859daf213bdda5a9f8d1be1d)         *
*                                                                      *
*                 Glenn Fowler <gsf@research.att.com>                  *
*                  David Korn <dgk@research.att.com>                   *
*                   Phong Vo <kpv@research.att.com>                    *
*                  Martijn Dekker <martijn@inlv.org>                   *
*            Johnothan King <johnothanking@protonmail.com>             *
*                                                                      *
***********************************************************************/

/*
 * Glenn Fowler
 * AT&T Research
 *
 * 8 bit character code map name/id lookup support
 */

#include <ast.h>
#include <ccode.h>
#include <ctype.h>

static const Ccmap_t	maps[] =
{
	{
	"ascii",
	"a|ascii|?(iso)?(-)646|?(iso)?(-)8859|latin",
	"8 bit ascii",
	"ISO-8859-%s",
	"1",
	CC_ASCII,
	},

	{
	"ebcdic",
	"e|ebcdic?(-)?([1e])",
	"X/Open ebcdic",
	"EBCDIC",
	NULL,
	CC_EBCDIC_E,
	},

	{
	"ebcdic-o",
	"o|ebcdic?(-)[3o]|?(cp|ibm)1047|open?(-)edition",
	"mvs OpenEdition ebcdic",
	"EBCDIC-O",
	NULL,
	CC_EBCDIC_O,
	},

	{
	"ebcdic-h",
	"h|ebcdic?(-)h|?(cp|ibm)?(00)37|[oa]s?(/-)400",
	"ibm OS/400 AS/400 ebcdic",
	"EBCDIC-H",
	NULL,
	CC_EBCDIC_H,
	},

	{
	"ebcdic-s",
	"s|ebcdic?(-)s|siemens|posix-bc",
	"siemens posix-bc ebcdic",
	"EBCDIC-S",
	NULL,
	CC_EBCDIC_S,
	},

	{
	"ebcdic-i",
	"i|ebcdic?(-)[2i]|ibm",
	"X/Open ibm ebcdic (not idempotent)",
	"EBCDIC-I",
	NULL,
	CC_EBCDIC_I,
	},

	{
	"ebcdic-m",
	"m|ebcdic?(-)m|mvs",
	"mvs ebcdic",
	"EBCDIC-M",
	NULL,
	CC_EBCDIC_M,
	},

	{
	"ebcdic-u",
	"u|ebcdic?(-)(u|mf)|microfocus",
	"microfocus cobol ebcdic",
	"EBCDIC-U",
	NULL,
	CC_EBCDIC_U,
	},

	{
	"native",
	"n|native|local",
	"native code set",
	NULL,
	NULL,
	CC_NATIVE,
	},

	{ 0 },
};

/*
 * ccode map list iterator
 */

Ccmap_t*
ccmaplist(Ccmap_t* mp)
{
	return !mp ? (Ccmap_t*)maps : (++mp)->name ? mp : NULL;
}

/*
 * return ccode map ID given name
 */

int
ccmapid(const char* name)
{
	const Ccmap_t*	mp;
	const Ccmap_t*	bp;
	int		c;
	ssize_t		n;
	ssize_t		sub[2];

	bp = NULL;
	n = 0;
	for (mp = maps; mp->name; mp++)
		if (strgrpmatch(name, mp->match, sub, elementsof(sub) / 2, STR_MAXIMAL|STR_LEFT|STR_ICASE))
		{
			if (!(c = name[sub[1]]))
				return mp->ccode;
			if (sub[1] > n && !isalpha(c))
			{
				n = sub[1];
				bp = mp;
			}
		}
	return bp ? bp->ccode : -1;
}

/*
 * return ccode map name given ID
 */

char*
ccmapname(int id)
{
	const Ccmap_t*	mp;

	for (mp = maps; mp->name; mp++)
		if (id == mp->ccode)
			return (char*)mp->name;
	return NULL;
}
