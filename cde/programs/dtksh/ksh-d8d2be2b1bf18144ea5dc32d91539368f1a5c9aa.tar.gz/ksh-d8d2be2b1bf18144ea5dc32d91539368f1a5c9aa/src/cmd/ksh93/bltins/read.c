/***********************************************************************
*                                                                      *
*               This software is part of the ast package               *
*          Copyright (c) 1982-2012 AT&T Intellectual Property          *
*          Copyright (c) 2020-2026 Contributors to ksh 93u+m           *
*                      and is licensed under the                       *
*                 Eclipse Public License, Version 2.0                  *
*                                                                      *
*                A copy of the License is available at                 *
*      https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html      *
*         (with md5 checksum 84283fa8859daf213bdda5a9f8d1be1d)         *
*                                                                      *
*                  David Korn <dgk@research.att.com>                   *
*                  Martijn Dekker <martijn@inlv.org>                   *
*            Johnothan King <johnothanking@protonmail.com>             *
*                                                                      *
***********************************************************************/
/*
 * read [-AaCprsSv] [-d delim] [-u fd] [-t timeout] [-n count] [-N count] [var?prompt] [var ...]
 *
 *   David Korn
 *   AT&T Labs
 *
 */

#include	"FEATURE/options"
#include	<ast.h>
#include	<error.h>
#include	"defs.h"
#include	"variables.h"
#include	"lexstates.h"
#include	"io.h"
#include	"name.h"
#include	"builtins.h"
#include	"history.h"
#include	"terminal.h"
#include	"edit.h"

#define R_FLAG	1	/* raw mode */
#if !SHOPT_SCRIPTONLY
#define S_FLAG	2	/* save in history file */
#endif
#define A_FLAG	4	/* read into array */
#define N_FLAG	8	/* fixed size read at most */
#define NN_FLAG	0x10	/* fixed size read exact */
#define V_FLAG	0x20	/* use default value */
#define C_FLAG	0x40	/* read into compound variable */
#define SS_FLAG	0x80	/* read .csv format file */

struct read_save
{
	char		**argv;
	char		*prompt;
	Sflong_t	timeout;
	size_t		plen;
	ssize_t		len;
	int		fd;
	int		flags;
};

int	b_read(int argc,char *argv[], Shbltin_t *context)
{
	Sfdouble_t sec;
	char *prompt, *eptr;
	const char *msg = e_file+4;
	int ret, flags=0, fd=0;
	int delim = '\n';
	uint8_t fdmode;
	ssize_t len=0;
	size_t q;
	Sflong_t timeout = sh.st.tmout && tty_check(0) ? 1000*(Sflong_t)sh.st.tmout : 0;
	int fixargs=context->invariant;
	short save_prompt;
	struct read_save *rp;
	static char default_prompt[3] = {ESC,ESC};
	rp = (struct read_save*)(context->data);
	if(argc==0)
	{
		if(rp)
			free(rp);
		return 0;
	}
	if(rp)
	{
		flags = rp->flags;
		timeout = rp->timeout;
		fd = rp->fd;
		argv = rp->argv;
		prompt = rp->prompt;
		q = rp->plen;
		goto bypass;
	}
	while((ret = optget(argv,sh_optread))) switch(ret)
	{
	    case 'A':
		flags |= A_FLAG;
		break;
	    case 'C':
		flags |= C_FLAG;
		break;
	    case 't':
		sec = sh_strnum(opt_info.arg, NULL,1);
		timeout = sec ? 1000*sec : 1;
		break;
	    case 'd':
		delim = *(unsigned char*)opt_info.arg;
		break;
	    case 'p':
	    coprocess:
		fd = sh.cpipe[0];
		msg = e_query;
		break;
	    case 'n': case 'N':
		flags |= (ret=='n'?N_FLAG:NN_FLAG);
		len = (ssize_t)opt_info.num;
		break;
	    case 'r':
		flags |= R_FLAG;
		break;
#if !SHOPT_SCRIPTONLY
	    case 's':
		/* save in history file */
		flags |= S_FLAG;
		break;
#endif
	    case 'S':
		flags |= SS_FLAG;
		break;
	    case 'u':
		if(opt_info.arg[0]=='p' && opt_info.arg[1]==0)
			goto coprocess;
		fd = strtoi(opt_info.arg,&eptr,10);
		if(errno == ERANGE || *eptr || !sh_iovalidfd(fd) || sh_inuse(fd))
			fd = -1;
		break;
	    case 'v':
		flags |= V_FLAG;
		break;
	    case ':':
		errormsg(SH_DICT,2, "%s", opt_info.arg);
		break;
	    case '?':
		return optselfdoc();
	}
	argv += opt_info.index;
	if(error_info.errors)
	{
		errormsg(SH_DICT,ERROR_usage(2), "%s", optusage(NULL));
		UNREACHABLE();
	}
	if(fd>=0 && (!((fdmode=sh.fdstatus[fd])&IOREAD) || !(fdmode&(IOSEEK|IONOSEEK))))
		fdmode = sh_iocheckfd(fd,NULL);
	if(fd<0 || !(fdmode&IOREAD))
	{
		errormsg(SH_DICT,ERROR_system(1),msg);
		UNREACHABLE();
	}
	/* look for prompt */
	if((prompt = *argv) && (prompt=strchr(prompt,'?')) && (fdmode&IOTTY))
		q = strlen(prompt++);
	else
		q = 0;
	if(argc==fixargs)
	{
		rp = sh_newof(NULL,struct read_save,1,0);
		context->data = (void*)rp;
		rp->fd = fd;
		rp->flags = flags;
		rp->timeout = timeout;
		rp->argv = argv;
		rp->prompt = prompt;
		rp->plen = q;
		rp->len = len;
	}
bypass:
	sh.prompt = default_prompt;
	if(q && (sh.prompt=(char*)sfreserve(sfstderr,(ssize_t)q,SFIO_LOCKR)))
	{
		memcpy(sh.prompt,prompt,q);
		sfwrite(sfstderr,sh.prompt,q-1);
	}
	sh.timeout = 0;
	save_prompt = sh.nextprompt;
	sh.nextprompt = 0;
	ret = sh_readline(argv,fd,flags,delim,len,timeout);
	sh.nextprompt = save_prompt;
	if(ret==0 && (ret=(sfeof(sh.sftable[fd])||sferror(sh.sftable[fd]))))
	{
		if(fd == sh.cpipe[0] && errno!=EINTR)
			sh_pclose(sh.cpipe);
	}
	return ret;
}

/*
 * here for read timeout
 */
static void timedout(void *handle)
{
	sfclrlock((Sfio_t*)handle);
	sh_exit(1);
}

/*
 * This is the code to read a line and to split it into tokens
 *  <names> is an array of variable names
 *  <fd> is the file descriptor
 *  <flags> is union of -A, -r, -s, and contains delimiter if not '\n'
 *  <timeout> is the number of milliseconds until timeout
 */
int sh_readline(char **_names, volatile int fd, int _flags, int _delim, ssize_t _size, Sflong_t timeout)
{
	ssize_t			c;
	unsigned char		*cp;
	Namval_t		*np;
	char			*name, *val;
	Sfio_t			*volatile iop;
	Namfun_t		*nfp;
	const char		*volatile ifs;
	unsigned char		*volatile cpmax;
	unsigned char		*del;
	volatile char		was_escape = 0;
	volatile char		use_stak = 0;
	volatile char		was_write = 0;
	volatile char		was_share = 1;
	volatile int		keytrap, flags = _flags, delim = _delim;
	volatile ssize_t	size = _size;
	int			wrd;
	ptrdiff_t		rel;
	long			array_index = 0;
	void			*volatile timeslot = NULL;
	int			jmpval=0;
	int			binary;
	nvflag_t		oflags=NV_VARNAME;
	char			inquote = 0;
	struct checkpt		buff;
	Edit_t			*ep = (struct edit*)sh.ed_context;
	char			**volatile names = _names;
	if(!(iop=sh.sftable[fd]) && !(iop=sh_iostream(fd,0)))
		return 1;
	sh_stats(STAT_READS);
	if(names && (name = *names))
	{
		Namval_t *mp;
		if(val= strchr(name,'?'))
			*val = 0;
		/*
		 * For -C to work, we need not only NV_ARRAY but also NV_ASSIGN. But an actual 'variable=value'
		 * assignment-argument would be nonsense and crashes the shell if allowed, so avoid setting
		 * NV_ASSIGN in that case, which lets nv_open issue the 'invalid variable name' error message.
		 */
		if(flags&C_FLAG && !strchr(name,'='))
			oflags |= NV_ARRAY|NV_ASSIGN;
		np = nv_open(name,sh.var_tree,oflags);
		if(!np)
		{
			errormsg(SH_DICT, ERROR_exit(2), e_create, name);
			UNREACHABLE();
		}
		if(nv_isarray(np) && (mp=nv_opensub(np)))
			np = mp;
		if((flags&V_FLAG) && sh.ed_context)
			((struct edit*)sh.ed_context)->e_default = np;
		if(flags&A_FLAG)
		{
			Namarr_t *ap;
			flags &= ~A_FLAG;
			array_index = 1;
			if((ap=nv_arrayptr(np)) && !ap->fun)
				ap->nelem++;
			nv_unset(np,0);
			if((ap=nv_arrayptr(np)) && !ap->fun)
				ap->nelem--;
			nv_putsub(np,NULL,0L);
		}
		else if(flags&C_FLAG)
		{
			void *sp = np->nvmeta;
			delim = -1;
			nv_unset(np,0);
			if(!nv_isattr(np,NV_MINIMAL))
				np->nvmeta = sp;
			nv_setvtree(np);
		}
		else
			name = *++names;
		if(val)
			*val = '?';
	}
	else
	{
		name = NULL;
		np = sh_scoped(REPLYNOD);
	}
	keytrap =  ep?ep->e_keytrap:0;
	ep->e_nttyparm.c_cc[VEOL] = (cc_t)delim;
	if(size || delim != '\n')	/* delimiter not new-line or fixed size read */
	{
		if((sh.fdstatus[fd]&IOTTY) && !keytrap)
			tty_raw(fd,1);
		ep->e_nttyparm.c_lflag |= ISIG;
		tty_set(fd,TCSADRAIN,&ep->e_nttyparm);
	}
	binary = nv_isattr(np,NV_BINARY);
	if(!binary)
	{
		Namval_t *mp;
		/* set up state table based on IFS */
		ifs = nv_getval(mp=sh_scoped(IFSNOD));
		if(!ifs)
			ifs = e_sptbnl; /* unset == default */
		if((flags&R_FLAG) && sh.ifstable['\\']==S_ESC)
			sh.ifstable['\\'] = 0;
		else if(!(flags&R_FLAG) && sh.ifstable['\\']==0)
			sh.ifstable['\\'] = S_ESC;
		if(delim>0)
			sh.ifstable[delim] = S_NL;
		if(delim!='\n')
		{
			if(strchr(ifs,'\n'))
				sh.ifstable['\n'] = S_DELIM;
			else
				sh.ifstable['\n'] = 0;
			nv_putval(mp, ifs, NV_RDONLY);
		}
		sh.ifstable[0] = S_EOF;
		if((flags&SS_FLAG))
		{
			sh.ifstable['"'] = S_QUOTE;
			sh.ifstable['\r'] = S_ERR;
		}
	}
	sfclrerr(iop);
	for(nfp=np->nvfun; nfp; nfp = nfp->next)
	{
		if(nfp->disc && nfp->disc->readf)
		{
			Namval_t *mp = nv_open(name,sh.var_tree,oflags|NV_NOREF);
			if((c=(*nfp->disc->readf)(mp,iop,delim,nfp))>=0)
				return (int)c;
		}
	}
	if(binary && !(flags&(N_FLAG|NN_FLAG)))
	{
		flags |= NN_FLAG;
		size = (ssize_t)nv_size(np);
	}
	was_write = (sfset(iop,SFIO_WRITE,0)&SFIO_WRITE)!=0;
	if(fd==0)
		was_share = (sfset(iop,SFIO_SHARE,sh.redir0!=2)&SFIO_SHARE)!=0;
	if(timeout || (sh.fdstatus[fd]&(IOTTY|IONOSEEK)))
	{
		sh_pushcontext(&buff,1);
		jmpval = sigsetjmp(buff.buff,0);
		if(jmpval)
			goto done;
		if(timeout)
			timeslot = sh_timeradd((Sfulong_t)timeout,0,timedout,iop);
	}
#if !SHOPT_SCRIPTONLY
	if((flags&S_FLAG) && !sh.hist_ptr)
	{
		sh_histinit();
		if(!sh.hist_ptr)
			flags &= ~S_FLAG;
	}
#endif
	if(flags&(N_FLAG|NN_FLAG))
	{
		char buf[256],*var=buf,*cur,*end,*up,*v;
		/* reserved buffer */
		if((c=size)>=(ssize_t)sizeof(buf))
		{
			var = (char*)sh_malloc((size_t)(c+1));
			end = var + c;
		}
		else
			end = var + sizeof(buf) - 1;
		up = cur = var;
		/* -n/-N: read only what is available instead of a whole record */
		sh.readavail = 1;
		if((sfset(iop,SFIO_SHARE,1)&SFIO_SHARE) && fd!=0)
			was_share = 1;
		if(size==0)
		{
			cp = sfreserve(iop,0,0);
			c = 0;
		}
		else
		{
			ptrdiff_t	m;
			int		f;
			for (;;)
			{
				c = size;
				if(keytrap)
				{
					cp = NULL;
					f = 0;
					m = 0;
					while(c-->0 && (buf[m]=(char)ed_getchar(ep,0)))
						m++;
					if(m>0)
						cp = (unsigned char*)buf;
				}
				else
				{
					f = 1;
					if(cp = sfreserve(iop,c,SFIO_LOCKR))
						m = sfvalue(iop);
					else if(flags&NN_FLAG)
					{
						c = size;
						m = (cp = sfreserve(iop,c,0)) ? sfvalue(iop) : 0;
						f = 0;
					}
					else
					{
						c = sfvalue(iop);
						m = (cp = sfreserve(iop,c,SFIO_LOCKR)) ? sfvalue(iop) : 0;
					}
				}
				if(m>0 && (flags&N_FLAG) && !binary && (v=memchr(cp,delim,(size_t)m)))
				{
					*v++ = 0;
					m = v-(char*)cp;
				}
				if((c=(ssize_t)m)>size)
					c = size;
				if(c>0)
				{
					if(c > (end-cur))
					{
						ptrdiff_t cx = cur - var, ux = up - var;
						m = (end - var) + (c - (end - cur));
						if (var == buf)
						{
							v = (char*)sh_malloc((size_t)(m+1));
							var = memcpy(v, var, (size_t)(cur - var));
						}
						else
							var = sh_newof(var, char, (size_t)m, 1);
						end = var + m;
						cur = var + cx;
						up = var + ux;
					}
					if(cur!=(char*)cp)
						memcpy(cur,cp,(size_t)c);
					if(f)
						sfread(iop,cp,(size_t)c);
					cur += c;
					if(mbwide() && !binary)
					{
						int	x;
						int	z;

						*cur = 0;
						x = z = 0;
						while (up < cur && (z = mbsize(up)) > 0)
						{
							up += z;
							x++;
						}
						if((size -= x) > 0 && (up >= cur || z < 0) && ((flags & NN_FLAG) || z < 0 || m > c))
							continue;
					}
				}
				if(mbwide() && !binary && (up == var || (flags & NN_FLAG) && size))
					cur = var;
				*cur = 0;
				if(c>=size || (flags&N_FLAG) || m==0)
				{
					if(m)
						sfclrerr(iop);
					break;
				}
				size -= c;
			}
		}
		if(timeslot)
		{
			sh_timerdel((void*)timeslot);
			timeslot = NULL;
		}
		if(binary && !((size=(ssize_t)nv_size(np)) && nv_isarray(np) && c!=size))
		{
#if SHOPT_OPTIMIZE
			/* only optimize this operation if the loop invariants optimizer is not being used */
			int optimize = !np->nvfun || !nv_hasdisc(np,&OPTIMIZE_disc);
#else
			int optimize = 1;
#endif
			if(optimize && c==size && np->nvalue && !nv_isarray(np))
				memcpy(np->nvalue,var,(size_t)c);
			else
			{
				Namval_t *mp;
				if(var==buf)
					var = sh_memdup(var,(size_t)c+1);
				nv_putval(np,var,NV_RAW);
				nv_setsize(np,(size_t)c);
				if(!nv_isattr(np,NV_MINIMAL|NV_EXPORT) && (mp = np->nvmeta))
					nv_setsize(mp,(size_t)c);
			}
		}
		else
		{
			nv_putval(np,var,0);
			if(var!=buf)
				free(var);
		}
		goto done;
	}
	else if(cp = (unsigned char*)sfgetr(iop,delim,0))
		c = sfvalue(iop);
	else if(cp = (unsigned char*)sfgetr(iop,delim,-1))
	{
		c = sfvalue(iop)+1;
		if(!sferror(iop) && sfgetc(iop) >=0)
		{
			errormsg(SH_DICT,ERROR_exit(1),e_overlimit,"line length");
			UNREACHABLE();
		}
	}
	if(timeslot)
	{
		sh_timerdel((void*)timeslot);
		timeslot = NULL;
	}
	if(cp)
	{
		cpmax = cp + c;
#if SHOPT_CRNL
		if(delim=='\n' && c>=2 && cpmax[-2]=='\r')
			cpmax--;
#endif /* SHOPT_CRNL */
		if(*(cpmax-1) != delim)
			*(cpmax-1) = (unsigned char)delim;
#if !SHOPT_SCRIPTONLY
		if(flags&S_FLAG)
			sfwrite(sh.hist_ptr->histfp,(char*)cp,(size_t)c);
#endif
		c = sh.ifstable[*cp++];
#if !SHOPT_MULTIBYTE
		if(!name && (flags&R_FLAG)) /* special case single argument */
		{
			/* skip over leading blanks */
			while(c==S_SPACE)
				c = sh.ifstable[*cp++];
			/* strip trailing delimiters */
			if(cpmax[-1] == delim)
				cpmax--;
			if(cpmax>cp)
			{
				while((c=sh.ifstable[*--cpmax])==S_DELIM && isspace(*cpmax) || c==S_SPACE);
				cpmax[1] = 0;
			}
			else
				*cpmax =0;
			if(nv_isattr(np, NV_RDONLY))
			{
				errormsg(SH_DICT,ERROR_warn(0),e_readonly, nv_name(np));
				jmpval = 1;
			}
			else
				nv_putval(np,(char*)cp-1,0);
			goto done;
		}
#endif /* !SHOPT_MULTIBYTE */
	}
	else
		c = S_NL;
	sh.nextprompt = 2;
	rel = stktell(sh.stk);
	/* val==0 at the start of a field */
	val = NULL;
	del = NULL;
	while(1)
	{
		ssize_t mbsz;
		switch(c)
		{
#if SHOPT_MULTIBYTE
		   case S_MBYTE:
			if(val==NULL)
				val = (char*)(cp-1);
			if(sh_strchr(ifs,(char*)cp-1)>=0)
			{
				c = mbsize((char*)cp-1);
				if(name)
					cp[-1] = 0;
				if(c>1)
					cp += (c-1);
				c = S_DELIM;
			}
			else
				c = 0;
			continue;
#endif /* SHOPT_MULTIBYTE */
		    case S_QUOTE:
			c = sh.ifstable[*cp++];
			if(inquote && c==S_QUOTE)
				c = -1;
			else
				inquote = !inquote;
			if(val)
			{
				sfputr(sh.stk,val,-1);
				use_stak = 1;
				*val = 0;
			}
			if(c==-1)
			{
				sfputc(sh.stk,'"');
				c = sh.ifstable[*cp++];
			}
			continue;
		    case S_ESC:
			/* process escape character */
			if((c = sh.ifstable[*cp++]) == S_NL)
				was_escape = 1;
			else
				c = 0;
			if(val)
			{
				sfputr(sh.stk,val,-1);
				use_stak = 1;
				was_escape = 1;
				*val = 0;
			}
			continue;

		    case S_ERR:
			cp++;
			/* FALLTHROUGH */
		    case S_EOF:
			/* check for end of buffer */
			if(val && *val)
			{
				sfputr(sh.stk,val,-1);
				use_stak = 1;
			}
			val = NULL;
			if(cp>=cpmax)
			{
				c = S_NL;
				break;
			}
			/* eliminate null bytes */
			c = sh.ifstable[*cp++];
			if(!name && val && (c==S_SPACE||c==S_DELIM||c==S_MBYTE))
				c = 0;
			continue;
		    case S_NL:
			if(was_escape)
			{
				was_escape = 0;
				if(cp = (unsigned char*)sfgetr(iop,delim,0))
					c = sfvalue(iop);
				else if(cp=(unsigned char*)sfgetr(iop,delim,-1))
					c = sfvalue(iop)+1;
				if(cp)
				{
#if !SHOPT_SCRIPTONLY
					if(flags&S_FLAG)
						sfwrite(sh.hist_ptr->histfp,(char*)cp,(size_t)c);
#endif
					cpmax = cp + c;
					c = sh.ifstable[*cp++];
					val = NULL;
					if(!name && (c==S_SPACE || c==S_DELIM || c==S_MBYTE))
						c = 0;
					continue;
				}
			}
			c = S_NL;
			break;

		    case S_SPACE:
			/* skip over blanks */
			while((c=sh.ifstable[*cp++])==S_SPACE);
			if(!val)
				continue;
#if SHOPT_MULTIBYTE
			if(c==S_MBYTE)
			{
				if(sh_strchr(ifs,(char*)cp-1)>=0)
				{
					if((c = mbsize((char*)cp-1))>1)
						cp += (c-1);
					c = S_DELIM;
				}
				else
					c = 0;
			}
#endif /* SHOPT_MULTIBYTE */
			if(c!=S_DELIM)
				break;
			/* FALLTHROUGH */

		    case S_DELIM:
			if(!del)
				del = cp - 1;
			if(name)
			{
				/* skip over trailing blanks */
				while((c=sh.ifstable[*cp++])==S_SPACE);
				break;
			}
			/* FALLTHROUGH */

		    case 0:
			if(val==NULL || was_escape)
			{
				val = (char*)(cp-1);
				was_escape = 0;
			}
			/* skip over word characters */
			wrd = -1;
			/* skip a preceding multibyte character, if any */
			if(c == 0 && (mbsz = mbsize(cp-1)) > 1)
				cp += mbsz - 1;
			while(1)
			{
				while((c = sh.ifstable[*cp]) == 0)
				{
					cp += (mbsz = mbsize(cp)) > 1 ? mbsz : 1;	/* treat invalid char as 1 byte */
					if(!wrd)
						wrd = 1;
				}
				cp++;
				if(inquote)
				{
					if(c==S_QUOTE)
					{
						if(sh.ifstable[*cp]==S_QUOTE)
						{
							if(val)
							{
								sfwrite(sh.stk,val,(size_t)(cp-(unsigned char*)val));
								use_stak = 1;
							}
							val = (char*)++cp;
						}
						else
							break;
					}
					if(c && c!=S_EOF)
					{
						if(c==S_NL)
						{
							if(val)
							{
								sfwrite(sh.stk,val,(size_t)(cp-(unsigned char*)val));
								use_stak=1;
							}
							if(cp = (unsigned char*)sfgetr(iop,delim,0))
								c = sfvalue(iop);
							else if(cp = (unsigned char*)sfgetr(iop,delim,-1))
								c = sfvalue(iop)+1;
							val = (char*)cp;
						}
						continue;
					}
				}
				if(!del&&c==S_DELIM)
					del = cp - 1;
				if(name || c==S_NL || c==S_ESC || c==S_EOF || c==S_MBYTE)
					break;
				if(wrd<0)
					wrd = 0;
			}
			if(wrd>0)
				del = (unsigned char*)"";
			if(c!=S_MBYTE)
				cp[-1] = 0;
			continue;
		}
		/* assign value and advance to next variable */
		if(!val)
			val = "";
		if(use_stak)
		{
			sfputr(sh.stk,val,0);
			val = stkptr(sh.stk,rel);
		}
		if(!name && *val)
		{
			/* strip off trailing space delimiters */
			unsigned char	*vp = (unsigned char*)val + strlen(val);
			while(sh.ifstable[*--vp]==S_SPACE || (isspace(*vp) && sh.ifstable[*vp]==S_DELIM));
			if(vp==del)
			{
				if(vp==(unsigned char*)val)
					vp--;
				else
					while(sh.ifstable[*--vp]==S_SPACE || (isspace(*vp) && sh.ifstable[*vp]==S_DELIM));
			}
			vp[1] = 0;
		}
		if(nv_isattr(np, NV_RDONLY))
		{
			errormsg(SH_DICT,ERROR_warn(0),e_readonly, nv_name(np));
			jmpval = 1;
		}
		else
			nv_putval(np,val,0);
		val = NULL;
		del = NULL;
		if(use_stak)
		{
			stkseek(sh.stk,rel);
			use_stak = 0;
		}
		if(array_index)
		{
			nv_putsub(np, NULL, array_index++);
			if(c!=S_NL)
				continue;
			name = *++names;
		}
		while(1)
		{
			if(name)
			{
				np = nv_open(name,sh.var_tree,NV_VARNAME);
				name = *++names;
			}
			else
				np = NULL;
			if(c!=S_NL)
				break;
			if(!np)
				goto done;
			if(nv_isattr(np, NV_RDONLY))
			{
				errormsg(SH_DICT,ERROR_warn(0),e_readonly, nv_name(np));
				jmpval = 1;
			}
			else
				nv_putval(np, "", 0);
		}
	}
done:
	sh.readavail = 0;
	if(timeslot)
		sh_timerdel((void*)timeslot);
	if(timeout || (sh.fdstatus[fd]&(IOTTY|IONOSEEK)))
		sh_popcontext(&buff);
	if(was_write)
		sfset(iop,SFIO_WRITE,1);
	if(!was_share)
		sfset(iop,SFIO_SHARE,0);
	if((sh.fdstatus[fd]&IOTTY) && !keytrap)
		tty_cooked(fd);
#if !SHOPT_SCRIPTONLY
	if((flags&S_FLAG) && hist_flush(sh.hist_ptr) < 0 && jmpval < 1)
		jmpval = 1;
#endif
	if(jmpval > 1)
		siglongjmp(*sh.jmplist,jmpval);
	return jmpval;
}
