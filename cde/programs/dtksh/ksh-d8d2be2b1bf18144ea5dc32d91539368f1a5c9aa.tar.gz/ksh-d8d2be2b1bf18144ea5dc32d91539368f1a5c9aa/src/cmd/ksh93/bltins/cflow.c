/***********************************************************************
*                                                                      *
*               This software is part of the ast package               *
*          Copyright (c) 1982-2012 AT&T Intellectual Property          *
*          Copyright (c) 2020-2026 Contributors to ksh 93u+m           *
*                      and is licensed under the                       *
*                 Eclipse Public License, Version 2.0                  *
*                                                                      *
*                A copy of the License is available at                 *
*      https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html      *
*         (with md5 checksum 84283fa8859daf213bdda5a9f8d1be1d)         *
*                                                                      *
*                  David Korn <dgk@research.att.com>                   *
*                  Martijn Dekker <martijn@inlv.org>                   *
*            Johnothan King <johnothanking@protonmail.com>             *
*                                                                      *
***********************************************************************/
/*
 * break [n]
 * continue [n]
 * return [n]
 * exit [n]
 *
 *   David Korn
 *   AT&T Labs
 *   dgk@research.att.com
 *
 */

#include	"FEATURE/options"
#include	"defs.h"
#include	<ast.h>
#include	<error.h>
#include	"shnodes.h"
#include	"builtins.h"

/*
 * return and exit
 */
#if 0
    /* for the dictionary generator */
    int	b_exit(int n, char *argv[],Shbltin_t *context){}
#endif
int	b_return(int n, char *argv[],Shbltin_t *context)
{
	/* 'return' outside of function, dotscript and profile behaves like 'exit' */
	const int do_exit = **argv=='e' || sh.fn_depth==0 && sh.dot_depth==0 && (!sh_isstate(SH_PROFILE) || sh.realsubshell);
	NOT_USED(context);
	while((n = optget(argv, **argv=='e' ? sh_optexit : sh_optreturn))) switch(n)
	{
	    case ':':
		if(!strmatch(argv[opt_info.index],"[+-]+([0-9])"))
			errormsg(SH_DICT,2, "%s", opt_info.arg);
		goto done;
	    case '?':
		return optselfdoc();
	}
done:
	if(error_info.errors)
	{
		errormsg(SH_DICT,ERROR_usage(2),"%s",optusage(NULL));
		UNREACHABLE();
	}
	argv += opt_info.index;
	if(*argv)
	{
		char *e;
		int oerrno = errno;
		errno = 0;
		n = strtoi(*argv, &e, 10);
		if(*e || errno==ERANGE)		/* check for overflow or bad number */
		{
			errormsg(SH_DICT,ERROR_system(0),errno==ERANGE?e_outofrange:e_number,*argv);
			n = 128;		/* overflow is undefined, so use a consistent status for this */
		}
		errno = oerrno;
		if(do_exit && sh.intrap)
			sh.intrap_exit_n = 1;
	}
	else
		n = sh.savexit;			/* no argument: pass down $? */
	if(do_exit)
		n &= SH_EXITMASK;		/* exit: apply bitmask before conversion to avoid undefined int overflow */
	((struct checkpt*)sh.jmplist)->mode = do_exit ? SH_JMPEXIT : SH_JMPFUN;
	sh_exit(sh.savexit = n);
	UNREACHABLE();
}


/*
 * break and continue
 */
#if 0
    /* for the dictionary generator */
    int	b_continue(int n, char *argv[],Shbltin_t *context){}
#endif
int	b_break(int n, char *argv[],Shbltin_t *context)
{
	char *arg;
	int cont= **argv=='c';
	NOT_USED(context);
	while((n = optget(argv,cont?sh_optcont:sh_optbreak))) switch(n)
	{
	    case ':':
		errormsg(SH_DICT,2, "%s", opt_info.arg);
		break;
	    case '?':
		return optselfdoc();
	}
	if(error_info.errors)
	{
		errormsg(SH_DICT,ERROR_usage(2),"%s",optusage(NULL));
		UNREACHABLE();
	}
	argv += opt_info.index;
	n=1;
	if(*argv)
	{
		int oerrno = errno;
		errno = 0;
		n = strtoi(*argv,&arg,10);
		if(n<=0 || *arg || errno==ERANGE)
		{
			errormsg(SH_DICT,ERROR_system(1),*arg?e_number:e_outofrange,*argv);
			UNREACHABLE();
		}
		errno = oerrno;
	}
	if(sh.st.loopcnt)
	{
		sh.st.breakcnt = n;
		if(sh.st.breakcnt > sh.st.loopcnt)
			sh.st.breakcnt = sh.st.loopcnt;
		if(cont)
			sh.st.breakcnt = -sh.st.breakcnt;
	}
	return 0;
}
