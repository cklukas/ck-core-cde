/***********************************************************************
*                                                                      *
*               This software is part of the ast package               *
*          Copyright (c) 1982-2011 AT&T Intellectual Property          *
*          Copyright (c) 2020-2026 Contributors to ksh 93u+m           *
*                      and is licensed under the                       *
*                 Eclipse Public License, Version 2.0                  *
*                                                                      *
*                A copy of the License is available at                 *
*      https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html      *
*         (with md5 checksum 84283fa8859daf213bdda5a9f8d1be1d)         *
*                                                                      *
*                  David Korn <dgk@research.att.com>                   *
*                  Martijn Dekker <martijn@inlv.org>                   *
*            Johnothan King <johnothanking@protonmail.com>             *
*                                                                      *
***********************************************************************/
#ifndef _ARGNOD_H
#define _ARGNOD_H
/*
 *	struct to hold a word argument
 *	Written by David Korn
 *
 */

struct ionod
{
	unsigned	iofile;
	char		*ioname;
	struct ionod	*ionxt;
	struct ionod	*iolst;
	char		*iodelim;
	off_t		iooffset;
	Sfoff_t		iosize;
	char		*iovname;
};

struct comnod
{
	int		comtyp;
	struct ionod	*comio;
	union
	{
		struct argnod	*ap;	/* use if (comtyp&COMSCAN) */
		struct dolnod	*dp;	/* use if (!(comtyp&COMSCAN)) */
	}		comarg;
	struct argnod	*comset;
	void		*comnamp;
	void		*comnamq;
	void		*comstate;
	int		comline;
};

#define COMBITS		4
#define COMMSK		((1<<COMBITS)-1)
#define COMSCAN		(01<<COMBITS)
#define COMFIXED	(02<<COMBITS)

struct slnod 	/* struct for linked list of stacks */
{
	struct slnod	*slnext;
	struct slnod	*slchild;
	Sfio_t		*slptr;
	/* slpad aligns struct functnod = struct slnod + 1 on some architectures */
	struct slnod	*slpad;
};

/*
 * This struct is used to hold $* lists and arrays
 */

struct dolnod
{
	int		dolrefcnt;	/* reference count */
	int		dolmax;		/* size of dolval array */
	int		dolnum;		/* number of elements */
	int		dolbot;		/* current first element */
	struct dolnod	*dolnxt;	/* used when lists are chained */
	char		*dolval[];	/* array of value pointers */
};

/*
 * This struct is used to hold word arguments of variable size during
 * parsing and during expansion.  The flags indicate what processing
 * is required on the argument.
 */

struct argnod
{
	union
	{
		struct argnod	*ap;
		char		*cp;
	}		argnxt;
	union
	{
		struct argnod	*ap;
		char		*cp;
		int		len;
	}		argchn;
	/*
	 * argflag must be 8 bits because the code expects that assigning
	 * to it will mask off any high bits; e.g., ARG_ARITH and friends.
	 */
	uint8_t		argflag;
	char		argval[];
};

/* The following should evaluate to the offset of argval in argnod */
#define ARGVAL		offsetof(struct argnod,argval[0])
#define sh_argstr(ap)	((ap)->argflag&ARG_RAW?sh_fmtq((ap)->argval):(ap)->argval)
#define ARG_SPARE 1

/* legal argument flags */
#define ARG_RAW		0x1	/* string needs no processing */
#define ARG_MAKE	0x2	/* bit set during argument expansion */
#define ARG_MAC		0x4	/* string needs macro expansion */
#define ARG_EXP		0x8	/* string needs file expansion */
#define ARG_ASSIGN	0x10	/* argument is an assignment */
#define ARG_QUOTED	0x20	/* word contained quote characters */
#define ARG_MESSAGE	0x40	/* contains international string */
#define ARG_APPEND	0x80	/* for += assignment */
#define ARG_ARRAY	0x2	/* for typeset -a */
/* The following can be passed as options to sh_macexpand() */
#define ARG_ARITH	0x100	/* arithmetic expansion */
#if SHOPT_OPTIMIZE
#define ARG_OPTIMIZE	0x200	/* try to optimize */
#else
#define ARG_OPTIMIZE	0
#endif /* SHOPT_OPTIMIZE */
#define ARG_NOGLOB	0x400	/* no file name expansion */
#define ARG_ARRAYOK	0x1000	/* $x[sub] ==> ${x[sub]} */

extern struct dolnod	*sh_argcreate(char*[]);
extern char 		*sh_argdolminus(void*);
extern int		sh_argopts(int,char*[]);

extern const char	e_heading[];
extern const char	e_subst[];
extern const char	e_exec[];

#endif /* _ARGNOD_H */
