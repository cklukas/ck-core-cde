/***********************************************************************
*                                                                      *
*               This software is part of the ast package               *
*          Copyright (c) 1982-2011 AT&T Intellectual Property          *
*          Copyright (c) 2020-2026 Contributors to ksh 93u+m           *
*                      and is licensed under the                       *
*                 Eclipse Public License, Version 2.0                  *
*                                                                      *
*                A copy of the License is available at                 *
*      https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.html      *
*         (with md5 checksum 84283fa8859daf213bdda5a9f8d1be1d)         *
*                                                                      *
*                  David Korn <dgk@research.att.com>                   *
*                  Martijn Dekker <martijn@inlv.org>                   *
*            Johnothan King <johnothanking@protonmail.com>             *
*                                                                      *
***********************************************************************/
/*
 * Ksh - AT&T Labs
 * Written by David Korn
 * This file defines all the read/write shell global variables
 */

#include	"FEATURE/options"
#include	"defs.h"
#include	"jobs.h"
#include	"shlex.h"

Shell_t			sh = {
	.cpipe[0] = -1,
	.coutpipe = -1,
#if _lib_openat
	.pwdfd = -1,
#endif
	.radixpoint = '.',	/* pre-locale init */
	.stk = stkstd
};

Dtdisc_t	_Nvdisc =
{
	.key = offsetof(Namval_t,nvname),
	.size = -1,
	.comparf = nv_compare
};

struct jobs	job = { 0 };
int32_t		sh_mailchk = 600;

#if SHOPT_KIA
Kia_t		kia;
#endif
